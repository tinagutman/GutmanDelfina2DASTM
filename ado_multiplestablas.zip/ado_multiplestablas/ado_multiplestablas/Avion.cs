﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ado_multiplestablas
{
    public class Avion
    {
        public int IdAvion { get; set; }
        public string Matricula { get; set; }
        public string Modelo { get; set; }
        public int Capacidad { get; set; }
    }
}

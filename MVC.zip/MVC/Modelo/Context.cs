﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo
{
    public class Context : DbContext
    {
        private string cadena = "Data Source=RCAL9P29-71314;Initial Catalog=Empresas;Integrated Security=True;Persist Security Info=False;Pooling=False;Encrypt=False;";
        public DbSet<Gerente> Gerentes { get; set; }
        public DbSet<Directorio> Directorios { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder options)=> options.UseSqlServer(cadena);
    }
}

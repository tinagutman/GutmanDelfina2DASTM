﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo
{
    public class Gerente
    {
        public int GerenteId { get; set; } 
        public string Nombre { get; set; }
        public string Area { get; set; }

        public int DirectorioId { get; set; }
        public Directorio Directorio { get; set; }
    }
}

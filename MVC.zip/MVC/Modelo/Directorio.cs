﻿namespace Modelo
{
    public class Directorio
    {
        public int DirectorioId { get; set; }
        public List<Gerente> listaGerentes { get; set; } = new();
    }
}
